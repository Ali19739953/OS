/*All libraries */
#include <stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
struct buffer{
int request;
int floor;
int destination;
};
int m;
int buffcount;
struct buffer b [10];
int count = 0;/* to keep track of the counter if full or not .*/
int totalrequests;
pthread_mutex_t buff; /*mutex*/
pthread_cond_t Buff;    /* conditional variable */
int t;/* time in seconds for sleep  */  
FILE *sim_out;
void* request(){	/*producer funtion*/

  FILE *file;
  
  if ((file = fopen("sim_input","r")) == NULL){
       perror("Error! opening file");

       /* Program exits if the file pointer returns NULL.*/
       exit(1);
   }
  


  	   pthread_mutex_lock(&buff);
  	  /*  pthread_cond_signal(&Buff);*/
  	   
    while (fscanf(file, "%d %d %d\n", &b[count].request,&b[count].floor,&b[count].destination)!=-1)
    {
   
   /* Add to the buffer.*/
       
       count++;
          
    }
       pthread_mutex_unlock(&buff);
        pthread_cond_signal(&Buff);
    
   return 0;
}

void* lift(void*liftnum){	/* consumer function*/
int liftNum=*((int*)liftnum);/* to return int*/ 
 free(liftnum);
/*int Curfloor; current floor of lift.*/
/*int gofloor; request to go to particular floor.*/
/*int totalmovesbylift; total moves by lifts*/
/*int totalrequests; totals requests by lifts*/
while(1){
   /*file write*/
   sim_out = fopen("sim_out","w");

   if(sim_out == NULL)
   {
      perror("Error!Cant write to file");   
      exit(1);             
   }
  pthread_mutex_lock(&buff);
  pthread_cond_signal(&Buff);
   
while(count!=0){
pthread_mutex_unlock(&buff);

count--;

 fprintf(sim_out,"Lift-%d Operation\n", liftNum);
fprintf(sim_out,"The lift is moving,Request number is %d floor number is %d to destination floor %d\n",b[count].request,b[count].floor,b[count].destination);


pthread_cond_wait(&Buff,&buff);
sleep(t);
 pthread_cond_signal(&Buff);

}

pthread_mutex_unlock(&buff);

pthread_exit(0);
}
fclose(sim_out);
}

int main(int argc, char* argv[])
{
 pthread_t Lift_R;/*creating thread lift_R*/
pthread_t lifts[3];
  int i;
if(argc != 3) /*command line arguments should not be less than 3.*/
    {
        perror("Error, Invalid number of command line arguments");
       
    }
    m = atoi(argv[1]);/*atoi is used to convert into an int*/
    t = atoi(argv[2]);
    if(m < 1 || t < 0) 
    {
        perror("Error, Invalid arguments!");
      
    }

	 pthread_cond_init (&Buff,  NULL);
	  
	pthread_mutex_init(&buff,NULL);/*initialzing the mutex*/
	
	   if(pthread_create(&Lift_R,NULL,&request,NULL)!=0){
 perror("Failed to create thread\n");
 return 1;
}
   if(pthread_join(Lift_R,NULL)!=0){/*neccesary to do otherwise it creates zombie threads.To terminate the thread we use pthread join.*/
 perror("Failed to join thread\n");
 return 2;
 }
	  
    for (i = 0; i < 3; i++) { /*created the lifts threads using loops to keep my main clean.*/
    int* a = malloc(sizeof(int));
     *a = i+1;
        if (pthread_create(lifts + i, NULL, &lift, a) != 0) {
            perror("Failed to create thread");
            return 3;
        }
       
    }
    for (i = 0; i < 3; i++) {
        if (pthread_join(lifts[i], NULL) != 0) {
            return 4;
        }
      
    }
	pthread_mutex_destroy(&buff);
      pthread_cond_destroy(&Buff);
      
	return 0;
	}
	


  
      
