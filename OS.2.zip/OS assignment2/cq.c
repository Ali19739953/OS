/*libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#define MAX_QUEUE_SIZE 10
/*struct for customer number and service time*/
typedef struct {
    int customerNum;
    int serviceTime;
    char arrivalTime[9];
} Customer;
/*to hold the queue size*/
Customer c_queue[MAX_QUEUE_SIZE];
/*vars to track queue*/
int queueSize = 0;
int queueFront = 0;
int queueRear = -1;
/*flags for threads to terminate*/
int terminationSignal=0;
int customerThreadsFinished=0;
int terminateFlag = 0; 
/*mutex locks and conditional variables*/
pthread_mutex_t Mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t queueNotFull = PTHREAD_COND_INITIALIZER;
pthread_cond_t queueNotEmpty = PTHREAD_COND_INITIALIZER;
/*vars to calculate time*/
char timeStringR[9];
char timeStringC[9];
time_t currentTime2;
struct tm* localTime2;
time_t currentTime3;
struct tm* localTime3;	
/*An array of size 3 to track the number of customers served by each teller*/
int servedCustomers[3] = {0,0,0};
char startTime1[9];
char startTime2[9];
char startTime3[9];
/*producer function*/
void enqueue(Customer customer) {
    pthread_mutex_lock(&Mutex);
FILE* logFile;
    while (queueSize == MAX_QUEUE_SIZE) {
    	sleep(2);
    	/*printf("Queeu size full\n");*/
        pthread_cond_wait(&queueNotFull, &Mutex);
    }
    queueRear = (queueRear + 1) % MAX_QUEUE_SIZE;
	time_t currentTime;
    struct tm* localTime;
    currentTime = time(NULL);

     /*Convert to local time*/
    localTime = localtime(&currentTime);
    strftime(customer.arrivalTime, sizeof(customer.arrivalTime), "%H:%M:%S", localTime);
    c_queue[queueRear] = customer;
    queueSize++;
    /*write to log_file*/
    logFile = fopen("r_log", "a");
    fprintf(logFile, "Customer# %d: Service_Time %d\n", customer.customerNum, customer.serviceTime);
    fprintf(logFile, "Arrival time: %s\n", customer.arrivalTime);
     fprintf(logFile, "----------------------------------\n");
    fclose(logFile);
    
    if(customer.customerNum==-1 && customer.serviceTime==-1){
    	customerThreadsFinished=1;
	}
    
    pthread_cond_signal(&queueNotEmpty);
    pthread_mutex_unlock(&Mutex);
    
}
/*function to remove the customers from the queue*/
Customer dequeue() {
    pthread_mutex_lock(&Mutex);
    
    while (queueSize == 0 && !terminationSignal) {
    	
        pthread_cond_wait(&queueNotEmpty, &Mutex);
    }
    
    Customer customer;
    if (queueSize==0 && terminationSignal) {
        pthread_mutex_unlock(&Mutex);
        //return (Customer) { -1, -1 };
        customer.customerNum=-1;
        customer.serviceTime=-1;
        memset(customer.arrivalTime,'\0',sizeof(customer.arrivalTime));
        return  customer;
    }
    
  customer = c_queue[queueFront];
    queueFront = (queueFront + 1) % MAX_QUEUE_SIZE;
   	queueSize--;
    
    pthread_cond_signal(&queueNotFull);
    pthread_mutex_unlock(&Mutex);
    
    return customer;
}
/*read file function and taking data*/
void* customer(void* arg) {
    FILE* file = fopen("c_file", "r");
    if (file == NULL) {
        perror("Error opening file");
        exit(1);
    }
    
    int customerNum, serviceTime;
    
    while (fscanf(file, "%d %d", &customerNum, &serviceTime) == 2) {
        Customer newCustomer;
        newCustomer.customerNum = customerNum;
        newCustomer.serviceTime = serviceTime;
        memset(newCustomer.arrivalTime, '\0', sizeof(newCustomer.arrivalTime));
        
          /*Simulate customer's arrival time*/
        sleep(2);
        enqueue(newCustomer);
        if (customerNum == -1) {
            break;
        }
           }
     
    fclose(file);
     pthread_mutex_lock(&Mutex);
    terminationSignal = 1;
    pthread_cond_broadcast(&queueNotEmpty);
    pthread_mutex_unlock(&Mutex);
     
    pthread_exit(NULL);
}
/*the consumer function,tellers */
void* teller(void* arg) {
	//pthread_mutex_lock(&Mutex);
 	int tellerNum = *(int*)arg;
 	int i =0;
    FILE* logFile;
    while (!terminateFlag) {
        Customer customer = dequeue();
        
        if (customer.customerNum == -1 && customer.serviceTime == -1) {
            break;
        }
        
        printf("Teller-%d serving customer %d\n", tellerNum, customer.customerNum);
        servedCustomers[tellerNum-1] = servedCustomers[tellerNum-1]+1;
        time(&currentTime2);
        localTime2 = localtime(&currentTime2);
        strftime(timeStringR, sizeof(timeStringR), "%H:%M:%S", localTime2);
         /*writing to log file*/
      logFile = fopen("r_log", "a");
       fprintf(logFile, "----------------------------------\n");
        fprintf(logFile, "Teller: %d\n", tellerNum);
        fprintf(logFile, "Customer: %d\n", customer.customerNum);
        fprintf(logFile, "Arrival time: %s\n", customer.arrivalTime);
        fprintf(logFile, "Response time: %s\n", timeStringR);
        fclose(logFile);
        if(i==0){
        	strcpy(startTime1 ,timeStringR);
		}
		if(i==1){
			strcpy(startTime2 ,timeStringR);
		}
		if(i==2){
			strcpy(startTime3 ,timeStringR);
		}
		i++;
      /*Simulate serving time*/
        sleep(customer.serviceTime);
        
        printf("Teller-%d finished serving customer %d\n", tellerNum, customer.customerNum);
       
        
        time(&currentTime3);
        localTime3 = localtime(&currentTime3);
        strftime(timeStringC, sizeof(timeStringC), "%H:%M:%S", localTime3);
        
        logFile = fopen("r_log", "a");
        fprintf(logFile, "----------------------------------\n");
        fprintf(logFile, "Teller: %d\n", tellerNum);
        fprintf(logFile, "Customer: %d\n", customer.customerNum);
        fprintf(logFile, "Arrival time: %s\n", customer.arrivalTime);
        fprintf(logFile, "Completetion Time: %s\n", timeStringC);
        fclose(logFile);
        
    }
    /* Write termination information to r_log file*/
   logFile = fopen("r_log", "a");
      fprintf(logFile, "----------------------------------\n");
            fprintf(logFile, "Termination: Teller-%d\n", 1);
            fprintf(logFile, "#served customers: %d\n", servedCustomers[0]);
            fprintf(logFile, "Start time: %s\n", startTime1);
               fprintf(logFile, "----------------------------------\n");
            //fprintf(logFile, "Termination time: %s\n", terminationTime1);
               fprintf(logFile, "----------------------------------\n");
            fprintf(logFile, "Termination: Teller-%d\n", 2);
            fprintf(logFile, "#served customers: %d\n", servedCustomers[1]);
            fprintf(logFile, "Start time: %s\n", startTime2);
               fprintf(logFile, "----------------------------------\n");
            //fprintf(logFile, "Termination time: %s\n", terminationTime2);
               fprintf(logFile, "----------------------------------\n");
            fprintf(logFile, "Termination: Teller-%d\n", 3);
            fprintf(logFile, "#served customers: %d\n", servedCustomers[2]);
            fprintf(logFile, "Start time: %s\n", startTime3);
               fprintf(logFile, "----------------------------------\n");
            //fprintf(logFile, "Termination time: %s\n", terminationTime3);
           
            fclose(logFile);
            
    /*Teller statistics*/
     
        logFile = fopen("r_log", "a");
          fprintf(logFile, "Teller Statistics\n");
        fprintf(logFile, "Teller Number: Teller-%d\n", 1);
        fprintf(logFile, "#served customers: %d\n", servedCustomers[0]);
          fprintf(logFile, "----------------------------------\n");
        fprintf(logFile, "Teller Number: Teller-%d\n", 2);
        fprintf(logFile, "#served customers: %d\n", servedCustomers[1]);
          fprintf(logFile, "----------------------------------\n");
        fprintf(logFile, "Teller Number: Teller-%d\n", 3);
        fprintf(logFile, "#served customers: %d\n", servedCustomers[2]);
          fprintf(logFile, "----------------------------------\n");
        fprintf(logFile, "#Total served customers: %d\n", servedCustomers[0]+servedCustomers[1]+servedCustomers[2]);
          fprintf(logFile, "----------------------------------\n");
        fclose(logFile);
    
    
    
    pthread_exit(NULL);
    
    //pthread_mutex_unlock(&Mutex);
}

int main(int argc, char* argv[]) {
if (argc < 2) {
    printf("Usage: ./program_name queue_size\n");
    return 1;
}

int queueSize = atoi(argv[1]);
if (queueSize <= 0) {
    printf("Invalid queue size. Please provide a positive integer value.\n");
    return 2;
}

/*producer*/
    pthread_t customerThread;
  /*consumer*/
    pthread_t tellerThreads[3];
    int i;
    int j;
    /*created threads and handling errors*/
    if(pthread_create(&customerThread, NULL, customer, NULL)!=0){
     perror("Failed to create thread\n");
 return 3;
 }
    
    int tellerNum[3] = {1, 2, 3};
    for (i = 0; i < 3; i++) {
        if(pthread_create(&tellerThreads[i], NULL, teller, &tellerNum[i])!=0,NULL){
         perror("Failed to create thread\n");
 return 4;
 }
}
    pthread_join(customerThread, NULL);
    /* Signal teller threads to terminate*/
    terminateFlag = 1;  
    sleep(1);
    for (j = 0; j < 3; j++) {
        pthread_join(tellerThreads[j], NULL);
    }
    pthread_mutex_destroy(&Mutex);
    pthread_cond_destroy(&queueNotFull);
    pthread_cond_destroy(&queueNotEmpty);
    /*printf("main line 238");*/
    printf("----------------------------------\n");
    printf("log_r file finally created,head out to the folder to check the stats\n");
    printf("Program terminated succesfully\n");
    return 0;
}
