To Run the File:
Type : Make
Then Type : ./cq m
where cq is the executable file name and m is the size of the array.
ex: ./cq 10 
"c_file" is the input file which contains customers(100) along with their service time and "r_log" will be the file created later with all the statistics.
once you run the program the file r_log will be created in the same directory.
"c_file" and cq file must be in the same directory for the program to run .
All of my work is done in one ".c" file which is the main file "cq.c".
